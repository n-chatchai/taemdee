# TaemDee · Design Handoff Package

`v1` — landing page + app screens + brand assets

## Contents

```
taemdee-package/
├── README.md                          ← this file
├── taemdee-home.html                  ← marketing landing page
├── taemdee-final-thai.html            ← 23 app mockups (C1-C7, S1-S12)
└── taemdee-icons/
    ├── taemdee-icon-32.png            ← favicon fallback (32×32)
    ├── taemdee-icon-192.png           ← Android home screen / PWA
    ├── taemdee-icon-512.png           ← large app icon, solid bg
    ├── taemdee-icon-transparent-512.png  ← over arbitrary bg (decks, prints)
    ├── taemdee-icon-line-oa-640.png   ← LINE OA profile pic (LINE requires solid bg)
    └── taemdee-icon-line-login-256.png ← LINE login button variant (white bg + green curve)
```

## Brand tokens

```
--bg:           #F6F1E5    (warm cream — page bg)
--surface:      #FDFAF2    (light cream — cards)
--ink:          #111111    (primary text)
--ink-soft:     #6B6660    (secondary text)
--ink-softer:   #A39D92    (tertiary text)
--accent:       #FF5E3A    (orange — primary brand color)
--butter:       #FFD952    (yellow — secondary accent)
--mint:         #C8E8D0    (success/ok states)
--line-green:   #06C755    (LINE brand green — for LINE-related UI only)
```

Fonts: Host Grotesk (display), Prompt (Thai body), JetBrains Mono (code/labels).

## Logo: Smile Stamp

Black rounded square (rx=22) with orange dot eyes + butter curve smile.
- Standard variant: black bg, orange eyes, butter curve
- LINE-login variant: white bg, orange eyes, GREEN curve (harmonizes with LINE green)
- Compact mark: just the curve+dots smile (no stamp container) for inline use at small sizes

## Files

### taemdee-home.html (marketing landing page)
nav -> hero (role chooser) -> for-shops -> how-it-works (3 steps with embedded C2/C1/C5 phones) -> for-customers (C1 phone) -> pricing -> testimonials -> faq -> final CTA -> footer

### taemdee-final-thai.html (23 app mockups)

Section 01 - Customer single-shop journey: C1, C2, C3, C4, C5
Section 02 - Customer account + cards: C6 (account menu), C7 (my cards)
Section 03 - Shop onboarding: S1 (shop), S1 (customer), S2.1-S2.4 (4-step setup)
Section 04 - Shop daily ops: S3 (DeeBoard), S5, S6, S7, S7.2
Section 05 - Shop settings: S8, S9, S10, S11, S12

## Key UX patterns

- Avatar pattern for menu entry: 38x38 accent-bg circle with initial. Tap = goes to settings/account. Used both shop (S3 -> S10) and customer (C7 -> C6).
- Back navigation: arrow in app-bar, consistent across sub-pages
- Soft Wall: customers use without registering, only required at redemption
- Anti-screenshot: live pulse counter shows "live - X seconds ago" on reward claim
- DeeReach: paid messaging via LINE/SMS, sender = TaemDee OA, content = shop's branded message

## Dev notes

1. All HTML is single-file (CSS + content inline)
2. SVG icons inline throughout - no external icon dependencies
3. Animations: gentle-spin, pulse-ring, blink-dot, twinkle-c - all CSS keyframes, no JS
4. Google Fonts via link preconnect
5. Color tokens at :root
6. Phone container 280-320px width, 9:19 aspect
7. Favicon = inline SVG data URI

## Open items not implemented yet

- [ ] DeeBoard staff variant (S3 with gated surfaces removed per PRD section 2)
- [ ] Offers integration (banner on DeeCard, DeeReach +free pastry offer toggle)
- [ ] Shop -> Shop referral (S10 entry + branded ?ref=X landing)
- [ ] Reward-mode picker in S12 add-branch flow (Shared vs Separate)
- [ ] LINE OA cover image (1080x878)
- [ ] LINE OA rich menu mockup
